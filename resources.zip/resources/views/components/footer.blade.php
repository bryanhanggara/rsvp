<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2025 <div class="bullet"></div> Develop By <a href="https://www.instagram.com/hangs.code/">HangsCode</a>
    </div>
    <div class="footer-right">
        1.0.0
    </div>
</footer>
