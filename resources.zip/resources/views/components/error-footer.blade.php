<div class="simple-footer mt-5">
    Copyright &copy; HangsCode 2025
</div>
