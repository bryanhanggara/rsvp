 <div class="login-brand">
     <img src="{{url('img/avatar/logo_kse.jpeg')}}"
         alt="logo"
         width="100"
         class="shadow-light rounded-circle">
 </div>
