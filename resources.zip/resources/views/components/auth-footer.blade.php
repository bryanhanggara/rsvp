  <div class="simple-footer">
      Develop &copy; HangsCode 2025
  </div>
